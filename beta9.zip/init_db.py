from models.db import init_db
init_db()
print('DB initialized')
